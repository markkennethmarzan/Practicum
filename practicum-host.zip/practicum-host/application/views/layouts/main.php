<?php $this->load->view('layouts/includes/header'); ?>
<?php $this->load->view($main_content); ?>
<?php $this->load->view('layouts/includes/footer'); ?>