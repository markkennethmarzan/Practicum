      	</div>
      </div>
    </div>
    </div>
  </div> <!-- /Row -->
</div><!-- /.container --> 

<div class="row footer">
	<div class="container">
		<p>Practicum Project &copy; 2018</p>
	</div>
</div>
</body>
</html>
