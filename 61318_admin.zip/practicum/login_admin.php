<?php include('server_admin.php') ?>

<!DOCTYPE html>
<html>
	
<head>
	<title>LOGIN : ADMIN</title>
	<link rel="stylesheet" type="text/css" href="../practicum/_CSS/_style.css">
	<link href="https://fonts.googleapis.com/css?family=Electrolize|Slabo+13px" rel="stylesheet">
</head>
	
<body>

	<div class="title_container">
		<a href="#" class="title">ADMIN's LOGIN</a>		
	</div>
	
	<form method="post" action="login_admin.php">
		<?php include('errors.php'); ?>
		
	<table class="t_adlog" align="center">
		<tr>
			<td>
				<label>USERNAME: </label>
			</td>		
			<td>
				<input type="text" name="a_username" style="width: 80%">
			</td>
		</tr>
		
		<tr>
			<td>
				<label>PASSWORD: </label>
			</td>
			<td>
				<input type="password" name="a_password" style="width: 80%">
			</td>
		</tr>
		
		<tr>
			<td colspan="2" align="center">
				<button type="submit" class="a_btn" name="log_admin">Login</button>
			</td>
		</tr>
	</table>		
	</form>


</body>
</html>