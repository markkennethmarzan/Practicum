<head>
	<link rel="stylesheet" type="text/css" href="../practicum/_CSS/_style.css">
</head>

<?php  if (count($errors) > 0) : ?>
	<div class="error">
		<?php foreach ($errors as $error) : ?>
			<p class="err_msg"><?php echo $error ?></p>
		<?php endforeach ?>
	</div>
<?php  endif ?>
