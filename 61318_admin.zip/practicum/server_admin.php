<?php 
	session_start();

	// variable declaration
	$firstname = "";
	$lastname = "";
	$username = "";
	$email = "";
	$errors = array(); 
	$_SESSION['success'] = "";

	// connect to database
	$db = mysqli_connect('localhost', 'root', '', "game");

	// REGISTER USER
	if (isset($_POST['reg_admin'])) {
		// receive all input values from the form
		$firstname = mysqli_real_escape_string($db, $_POST['ar_firstname']);
		$lastname = mysqli_real_escape_string($db, $_POST['ar_lastname']);
		$username = mysqli_real_escape_string($db, $_POST['ar_username']);
		$email = mysqli_real_escape_string($db, $_POST['ar_email']);
		$password_f = mysqli_real_escape_string($db, $_POST['ar_password']);
		$password_conf = mysqli_real_escape_string($db, $_POST['ar_conf_password']);

		// form validation: ensure that the form is correctly filled
		if (empty($firstname)) { array_push($errors, "Firstrname is required"); }
		if (empty($lastname)) { array_push($errors, "Lastname is required"); }
		if (empty($username)) { array_push($errors, "Username is required"); }
		if (empty($email)) { array_push($errors, "Email is required"); }
		if (empty($password_f)) { array_push($errors, "Password is required"); }
		if (empty($password_conf)) { array_push($errors, "Confirmation password is required"); }

		if ($password_f != $password_conf) {
			array_push($errors, "The two passwords do not match");
		}

		// register user if there are no errors in the form
		if (count($errors) == 0) {
			$password = md5($password_f);//encrypt the password before saving in the database
			$query = "INSERT INTO admin (firstname, lastname, email, username, password) 
					  VALUES('$firstname','$lastname', '$email','$username', '$password')";
			mysqli_query($db, $query);

			$_SESSION['username'] = $username;
			$_SESSION['success'] = "You've successfully registered your account!";
			header('location: admin.php');
		}

	}

	// ... 

	// LOGIN USER
	if (isset($_POST['log_admin'])) {
		$username = mysqli_real_escape_string($db, $_POST['a_username']);
		$password = mysqli_real_escape_string($db, $_POST['a_password']);

		if (empty($username)) {
			array_push($errors, "Username is required");
		}
		if (empty($password)) {
			array_push($errors, "Password is required");
		}

		if (count($errors) == 0) {
			$password = md5($password);
			$query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
			$results = mysqli_query($db, $query);

			if (mysqli_num_rows($results) == 1) {
				$_SESSION['username'] = $username;
				$_SESSION['success'] = "You've successfully logged in!";
				header('location: admin.php');
			}else {
				array_push($errors, "You have entered an invalid credentials!");
			}
		}
	}
?>