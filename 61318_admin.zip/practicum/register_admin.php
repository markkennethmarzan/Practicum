<?php include('server_admin.php') ?>

<!DOCTYPE html>
<html>
	
<head>
	<title>REGISTRATION : ADMIN</title>
	<link rel="stylesheet" type="text/css" href="../practicum/_CSS/_style.css">
	<link href="https://fonts.googleapis.com/css?family=Electrolize|Slabo+13px" rel="stylesheet">
</head>
	
<body>
	<div class="title_container">
		<a href="admin.php" class="title">ADMIN's REGISTRATION</a>		
	</div>
	
	<form method="post" action="register_admin.php">
		<?php include('errors.php'); ?>
		
	<table class="t_adreg" align="center">
		<tr>
			<td colspan="2" class="reg_tdheader">
				<b><p class="rem_reg">Enter the required personal info</p>
				<p class="rem_reg">to register:</p></b>
			</td>
		</tr>
		
		<tr>
			<td>
			<label>Firstname: </label>
			</td>
			<td>
			<input style="width: 80%" type="text" name="ar_firstname" value="<?php echo $firstname; ?>">
			</td>
		</tr>
		
		<tr>
			<td>
			<label>Lastname: </label>
			</td>
			<td>
			<input style="width: 80%" type="text" name="ar_lastname" value="<?php echo $lastname; ?>">
			</td>
		</tr>
		
		<tr>
			<td>
			<label>Username: </label>
			</td>
			<td>
			<input style="width: 80%" type="text" name="ar_username" value="<?php echo $username; ?>">
			</td>
		</tr>
		
		<tr>
			<td>
			<label>Email: </label>
			</td>
			<td>
			<input style="width: 80%" type="email" name="ar_email" value="<?php echo $email; ?>">
			</td>
		</tr>
		
		<tr>
			<td>
			<label>Password: </label>
			</td>
			<td>
			<input style="width: 80%" type="password" name="ar_password">
			</td>
		</tr>
		
		<tr>
			<td>
			<label>Confirm password: </label>
			</td>
			<td>
			<input style="width: 80%" type="password" name="ar_conf_password">
			</td>
		</tr>
		
		<tr>
			<td colspan="2" align="center">
			<button type="submit" name="reg_admin">Register</button>
			</td>
		</tr>
		</table>
	</form>
</body>
</html>