</div>
			</div>
			</div>
		</div>
    </div><!-- /.container -->
	
	<div class="row footer">
		<div class="container">
			<p>The Gaming Place &copy; 2014, All Rights Reserved</p>
		</div>
	</div>

   
  </body>
</html>